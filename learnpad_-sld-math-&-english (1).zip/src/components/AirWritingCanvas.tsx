import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { soundService } from '@/src/services/sound';
import { speakService } from '@/src/services/speak';
import { cn } from '@/src/lib/utils';

interface AirWritingCanvasProps {
  targetLetter: string;
  color?: string;
  onComplete?: () => void;
  className?: string;
}

export const AirWritingCanvas = ({
  targetLetter,
  color = '#FFDAC1', // Default pastel pink
  onComplete,
  className,
}: AirWritingCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const lastPos = useRef({ x: 0, y: 0 });

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size to match display size
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };

    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  const startDrawing = (x: number, y: number) => {
    setIsDrawing(true);
    setHasDrawn(true);
    lastPos.current = { x, y };
    soundService.play('scribble');
  };

  const draw = (x: number, y: number) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(x, y);
    
    // Magic/Neon Effect
    ctx.strokeStyle = color;
    ctx.lineWidth = 20;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Glow
    ctx.shadowBlur = 15;
    ctx.shadowColor = color;
    
    ctx.stroke();
    lastPos.current = { x, y };
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  // Event Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) startDrawing(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) draw(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    const touch = e.touches[0];
    if (rect) startDrawing(touch.clientX - rect.left, touch.clientY - rect.top);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    const touch = e.touches[0];
    if (rect) draw(touch.clientX - rect.left, touch.clientY - rect.top);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx && canvas) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setHasDrawn(false);
    }
  };

  return (
    <div className={cn("relative w-full h-full bg-white rounded-3xl cartoon-border cartoon-shadow overflow-hidden", className)}>
      {/* Tracing Guide Layer (SVG) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-10">
        <svg 
          width="100%" 
          height="100%" 
          viewBox="0 0 100 100" 
          preserveAspectRatio="xMidYMid meet"
          className="w-4/5 h-4/5"
        >
          <text
            x="50"
            y="55"
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize="90"
            fontWeight="900"
            fill="none"
            stroke="currentColor"
            strokeWidth="0.5"
            strokeDasharray="2,2"
            className="text-slate-900"
          >
            {targetLetter}
          </text>
        </svg>
      </div>

      {/* Drawing Canvas Layer */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={stopDrawing}
        className="relative z-10 w-full h-full cursor-crosshair touch-none"
      />
      
      <div className="absolute top-6 right-6 flex flex-col gap-4">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={clearCanvas}
          className="w-16 h-16 bg-white cartoon-border cartoon-shadow-sm rounded-2xl flex items-center justify-center text-2xl"
          title="Clear"
        >
          🧹
        </motion.button>
      </div>

      {!hasDrawn && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <motion.div 
            animate={{ y: [0, -20, 0], opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="text-slate-300 text-xl font-bold uppercase tracking-widest"
          >
            Trace the letter {targetLetter}
          </motion.div>
        </div>
      )}
    </div>
  );
};
