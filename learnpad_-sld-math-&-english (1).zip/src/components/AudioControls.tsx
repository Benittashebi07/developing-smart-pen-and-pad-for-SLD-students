import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, RotateCcw } from 'lucide-react';
import { soundService } from '@/src/services/sound';
import { speakService } from '@/src/services/speak';
import { CartoonButton } from './CartoonUI';
import { cn } from '@/src/lib/utils';

export const AudioControls = ({ onReplay }: { onReplay?: () => void }) => {
  const [isMuted, setIsMuted] = useState(soundService.getMute());

  const toggleMute = () => {
    const newMute = !isMuted;
    setIsMuted(newMute);
    soundService.setMute(newMute);
    speakService.setMute(newMute);
    
    if (!newMute) {
      soundService.play('click');
      speakService.speak('Sound is on');
    }
  };

  return (
    <div className="flex gap-2">
      {onReplay && (
        <CartoonButton 
          variant="white" 
          className="p-3" 
          onClick={() => {
            soundService.play('click');
            onReplay();
          }}
          title="Repeat Instruction"
        >
          <RotateCcw size={24} />
        </CartoonButton>
      )}
      <CartoonButton 
        variant="white" 
        className="p-3" 
        onClick={toggleMute}
        title={isMuted ? "Unmute" : "Mute"}
      >
        {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
      </CartoonButton>
    </div>
  );
};
