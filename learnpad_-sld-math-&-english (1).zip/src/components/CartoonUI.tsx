import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface CartoonButtonProps extends HTMLMotionProps<"button"> {
  variant?: 'blue' | 'yellow' | 'green' | 'pink' | 'purple' | 'white';
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const CartoonButton = ({
  variant = 'blue',
  size = 'md',
  className,
  children,
  ...props
}: CartoonButtonProps) => {
  const variants = {
    blue: 'bg-brand-blue hover:bg-brand-blue/90',
    yellow: 'bg-brand-yellow hover:bg-brand-yellow/90',
    green: 'bg-brand-green hover:bg-brand-green/90',
    pink: 'bg-brand-pink hover:bg-brand-pink/90',
    purple: 'bg-brand-purple hover:bg-brand-purple/90',
    white: 'bg-white hover:bg-slate-50',
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-lg font-bold',
    lg: 'px-8 py-4 text-xl font-bold',
    xl: 'px-12 py-6 text-2xl font-black',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95, translateY: 4 }}
      className={cn(
        'cartoon-border cartoon-shadow rounded-xl transition-colors active:shadow-none',
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </motion.button>
  );
};

interface CartoonCardProps {
  variant?: 'blue' | 'yellow' | 'green' | 'pink' | 'purple' | 'white';
  className?: string;
  children: React.ReactNode;
  animate?: boolean;
}

export const CartoonCard = ({
  variant = 'white',
  className,
  children,
  animate = true,
}: CartoonCardProps) => {
  const variants = {
    blue: 'bg-brand-blue/20 border-brand-blue',
    yellow: 'bg-brand-yellow/20 border-brand-yellow',
    green: 'bg-brand-green/20 border-brand-green',
    pink: 'bg-brand-pink/20 border-brand-pink',
    purple: 'bg-brand-purple/20 border-brand-purple',
    white: 'bg-white border-slate-200',
  };

  const Component = animate ? motion.div : 'div';

  return (
    <Component
      initial={animate ? { opacity: 0, y: 20 } : undefined}
      animate={animate ? { opacity: 1, y: 0 } : undefined}
      className={cn(
        'cartoon-border cartoon-shadow rounded-2xl p-6',
        variants[variant],
        className
      )}
    >
      {children}
    </Component>
  );
};
