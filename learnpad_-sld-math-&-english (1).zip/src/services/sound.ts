/**
 * Sound Effects Service
 * Handles preloading and playing of audio files using native browser Audio API.
 */

class SoundService {
  private sounds: Map<string, HTMLAudioElement> = new Map();
  private isMuted: boolean = false;

  // Predefined sound URLs
  private soundUrls: Record<string, string> = {
    click: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
    correct: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
    wrong: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
    reward: 'https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3',
    transition: 'https://assets.mixkit.co/active_storage/sfx/2567/2567-preview.mp3',
    scribble: 'https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3',
  };

  constructor() {
    this.preloadSounds();
  }

  private preloadSounds() {
    Object.entries(this.soundUrls).forEach(([name, url]) => {
      const audio = new Audio(url);
      audio.preload = 'auto';
      this.sounds.set(name, audio);
    });
  }

  public play(name: string) {
    if (this.isMuted) return;

    const audio = this.sounds.get(name);
    if (audio) {
      // Reset sound to start if it's already playing
      audio.currentTime = 0;
      audio.play().catch(err => console.warn('Audio playback failed:', err));
    } else if (this.soundUrls[name]) {
      // Fallback for sounds not preloaded
      const newAudio = new Audio(this.soundUrls[name]);
      newAudio.play().catch(err => console.warn('Audio playback failed:', err));
    }
  }

  public stopAll() {
    this.sounds.forEach(audio => {
      audio.pause();
      audio.currentTime = 0;
    });
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (muted) this.stopAll();
  }

  public getMute() {
    return this.isMuted;
  }
}

export const soundService = new SoundService();
