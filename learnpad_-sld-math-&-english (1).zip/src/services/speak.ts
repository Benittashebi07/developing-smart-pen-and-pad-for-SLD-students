/**
 * Text-to-Speech Service
 * Uses the Web Speech API (SpeechSynthesis) to provide voice guidance.
 * Optimized for children with slower speech rates and clear pronunciation.
 */

class SpeakService {
  private synthesis: SpeechSynthesis | null = null;
  private isMuted: boolean = false;
  private defaultRate: number = 0.8;
  private defaultPitch: number = 1.1;
  private voices: SpeechSynthesisVoice[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      this.synthesis = window.speechSynthesis;
      this.loadVoices();
      
      // Handle asynchronous voice loading
      if (this.synthesis.onvoiceschanged !== undefined) {
        this.synthesis.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synthesis) return;
    this.voices = this.synthesis.getVoices();
    if (this.voices.length > 0) {
      console.log(`🔊 Loaded ${this.voices.length} voices`);
    }
  }

  private getBestVoice(): SpeechSynthesisVoice | null {
    if (this.voices.length === 0) {
      this.loadVoices();
    }

    // Priority: 1. Google en-US, 2. Any en-US, 3. Any en, 4. First available
    return (
      this.voices.find(v => v.lang === 'en-US' && v.name.includes('Google')) ||
      this.voices.find(v => v.lang === 'en-US') ||
      this.voices.find(v => v.lang.startsWith('en')) ||
      this.voices[0] ||
      null
    );
  }

  public speak(text: string, options?: { rate?: number; pitch?: number }) {
    if (!this.synthesis || this.isMuted) {
      console.warn('🔇 Speech skipped: Synthesis not available or muted');
      return;
    }

    console.log(`🗣️ Request to speak: "${text}"`);

    // 1. Cancel any ongoing speech to prevent queue issues
    this.synthesis.cancel();

    // 2. Create the utterance
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options?.rate ?? this.defaultRate;
    utterance.pitch = options?.pitch ?? this.defaultPitch;
    utterance.lang = 'en-US';

    // 3. Attach a voice
    const voice = this.getBestVoice();
    if (voice) {
      utterance.voice = voice;
      console.log(`🎙️ Using voice: ${voice.name} (${voice.lang})`);
    } else {
      console.warn('⚠️ No voices available yet, using system default');
    }

    // 4. Event handlers
    utterance.onstart = () => console.log('▶️ Speech started');
    utterance.onend = () => console.log('✅ Speech finished');
    utterance.onerror = (event) => {
      console.error('❌ SpeechSynthesisErrorEvent:', event);
      // If it fails, try to resume the engine which sometimes gets stuck
      this.synthesis?.resume();
    };

    // 5. Speak!
    // Wrap in a small timeout to ensure cancel() has finished processing
    setTimeout(() => {
      this.synthesis?.speak(utterance);
    }, 50);
  }

  public stop() {
    if (this.synthesis) {
      this.synthesis.cancel();
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (muted) this.stop();
  }
}

export const speakService = new SpeakService();
