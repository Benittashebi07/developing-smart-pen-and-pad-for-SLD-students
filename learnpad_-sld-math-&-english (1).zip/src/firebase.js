// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// ---------------------------------------------------------
// 1. CONFIGURATION
// ---------------------------------------------------------
// IMPORTANT: You must replace these placeholders with your 
// actual values from the Firebase Console (Project Settings > General)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// 2. INITIALIZATION
console.log("🚀 Firebase: Starting initialization...");

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

console.log("✅ Firebase: Firestore reference created!");
