import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Plus, 
  Lock, 
  Calculator, 
  BookOpen, 
  BarChart3, 
  Star, 
  Award, 
  Volume2, 
  RotateCcw, 
  ChevronLeft,
  Home,
  User,
  Settings,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { CartoonButton, CartoonCard } from '@/src/components/CartoonUI';
import { cn } from '@/src/lib/utils';
import { AirWritingCanvas } from '@/src/components/AirWritingCanvas';
import { AudioControls } from '@/src/components/AudioControls';
import { Sparkles, Eraser, ArrowRight } from 'lucide-react';
import { soundService } from '@/src/services/sound';
import { speakService } from '@/src/services/speak';
import ScoreTracker from './ScoreTracker';

// --- Types ---
type Screen = 'welcome' | 'profiles' | 'dashboard' | 'math' | 'english' | 'progress' | 'rewards' | 'tracing' | 'scores';

interface Profile {
  id: string;
  name: string;
  avatar: string;
  stars: number;
  level: number;
}

// --- Mock Data ---
const MOCK_PROFILES: Profile[] = [
  { id: '1', name: 'Leo', avatar: '🦁', stars: 124, level: 5 },
  { id: '2', name: 'Mia', avatar: '🐱', stars: 89, level: 3 },
];

const PROGRESS_DATA = [
  { day: 'Mon', math: 12, english: 8 },
  { day: 'Tue', math: 15, english: 12 },
  { day: 'Wed', math: 8, english: 15 },
  { day: 'Thu', math: 20, english: 10 },
  { day: 'Fri', math: 18, english: 20 },
];

const WEEKLY_DATA = [
  { week: 'W1', score: 65 },
  { week: 'W2', score: 72 },
  { week: 'W3', score: 85 },
  { week: 'W4', score: 92 },
];

// --- Components ---

const WelcomeScreen = ({ onStart }: { onStart: () => void }) => (
  <div className="h-screen w-full flex flex-col items-center justify-center relative overflow-hidden bg-brand-blue/10">
    {/* Animated Background Elements */}
    <div className="absolute top-10 left-10 animate-float opacity-50">
      <div className="w-20 h-20 bg-brand-yellow rounded-full blur-xl" />
    </div>
    <div className="absolute bottom-20 right-20 animate-float opacity-50" style={{ animationDelay: '1s' }}>
      <div className="w-32 h-32 bg-brand-pink rounded-full blur-2xl" />
    </div>
    
    <motion.div 
      initial={{ scale: 0.5, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="text-center z-10"
    >
      <div className="text-9xl mb-8 animate-bounce">🦉</div>
      <h1 className="text-6xl font-black text-slate-800 mb-4 font-display">LearnPad</h1>
      <p className="text-2xl text-slate-600 mb-12 max-w-md mx-auto">
        Fun learning for everyone!
      </p>
      
      <CartoonButton size="xl" variant="yellow" onClick={() => { soundService.play('click'); onStart(); }}>
        <div className="flex items-center gap-4">
          <Play fill="currentColor" size={32} />
          START LEARNING
        </div>
      </CartoonButton>
    </motion.div>
  </div>
);

const ProfileSelection = ({ onSelect }: { onSelect: (p: Profile) => void }) => (
  <div className="h-screen w-full p-12 flex flex-col items-center justify-center bg-brand-green/5">
    <h2 className="text-4xl font-black mb-12 font-display">Who is learning today?</h2>
    
    <div className="flex gap-8 flex-wrap justify-center">
      {MOCK_PROFILES.map((profile) => (
        <motion.div
          key={profile.id}
          whileHover={{ y: -10 }}
          onClick={() => { soundService.play('click'); onSelect(profile); }}
          className="cursor-pointer"
        >
          <CartoonCard className="w-48 h-64 flex flex-col items-center justify-center gap-4 hover:bg-brand-blue/10 transition-colors">
            <div className="text-7xl">{profile.avatar}</div>
            <div className="text-2xl font-bold">{profile.name}</div>
            <div className="flex items-center gap-1 text-brand-yellow-dark font-bold">
              <Star size={16} fill="#FFD700" color="#FFD700" />
              {profile.stars}
            </div>
          </CartoonCard>
        </motion.div>
      ))}
      
      <motion.div whileHover={{ y: -10 }} className="cursor-pointer">
        <CartoonCard className="w-48 h-64 flex flex-col items-center justify-center gap-4 border-dashed border-4 border-slate-300 bg-transparent shadow-none">
          <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center">
            <Plus size={40} className="text-slate-400" />
          </div>
          <div className="text-xl font-bold text-slate-400">Add New</div>
        </CartoonCard>
      </motion.div>
    </div>
    
    <button className="mt-12 flex items-center gap-2 text-slate-400 hover:text-slate-600 transition-colors">
      <Lock size={20} />
      <span className="font-bold">Parent Mode</span>
    </button>
  </div>
);

const Dashboard = ({ profile, onNavigate }: { profile: Profile, onNavigate: (s: Screen) => void }) => (
  <div className="h-screen w-full p-8 bg-brand-blue/5 overflow-y-auto">
    <header className="flex justify-between items-center mb-12">
      <div className="flex items-center gap-4">
        <div className="text-5xl">{profile.avatar}</div>
        <div>
          <h2 className="text-3xl font-black font-display">Hi, {profile.name}!</h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-amber-500 font-bold">
              <Star size={20} fill="currentColor" />
              {profile.stars}
            </div>
            <div className="bg-brand-purple/20 px-3 py-1 rounded-full text-brand-purple-dark font-bold text-sm">
              Level {profile.level}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="bg-white cartoon-border cartoon-shadow-sm px-4 py-2 rounded-xl flex items-center gap-2">
          <span className="text-2xl">🔥</span>
          <span className="font-black">3 Day Streak!</span>
        </div>
        <AudioControls />
      </div>
    </header>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <motion.div whileHover={{ scale: 1.02 }} onClick={() => { soundService.play('click'); onNavigate('math'); }}>
        <CartoonCard variant="blue" className="h-80 flex flex-col items-center justify-center cursor-pointer">
          <div className="w-32 h-32 bg-brand-blue rounded-full flex items-center justify-center mb-6 cartoon-border">
            <Calculator size={64} className="text-white" />
          </div>
          <h3 className="text-3xl font-black mb-2">Math</h3>
          <p className="text-slate-600 font-medium">Numbers & Shapes</p>
        </CartoonCard>
      </motion.div>

      <motion.div whileHover={{ scale: 1.02 }} onClick={() => { soundService.play('click'); onNavigate('english'); }}>
        <CartoonCard variant="pink" className="h-80 flex flex-col items-center justify-center cursor-pointer">
          <div className="w-32 h-32 bg-brand-pink rounded-full flex items-center justify-center mb-6 cartoon-border">
            <BookOpen size={64} className="text-white" />
          </div>
          <h3 className="text-3xl font-black mb-2">English</h3>
          <p className="text-slate-600 font-medium">Letters & Words</p>
        </CartoonCard>
      </motion.div>

      <motion.div whileHover={{ scale: 1.02 }} onClick={() => { soundService.play('click'); onNavigate('progress'); }}>
        <CartoonCard variant="green" className="h-80 flex flex-col items-center justify-center cursor-pointer">
          <div className="w-32 h-32 bg-brand-green rounded-full flex items-center justify-center mb-6 cartoon-border">
            <BarChart3 size={64} className="text-white" />
          </div>
          <h3 className="text-3xl font-black mb-2">Progress</h3>
          <p className="text-slate-600 font-medium">See your growth</p>
        </CartoonCard>
      </motion.div>

      <motion.div whileHover={{ scale: 1.02 }} onClick={() => { soundService.play('click'); onNavigate('scores'); }}>
        <CartoonCard variant="purple" className="h-80 flex flex-col items-center justify-center cursor-pointer">
          <div className="w-32 h-32 bg-brand-purple rounded-full flex items-center justify-center mb-6 cartoon-border">
            <Award size={64} className="text-white" />
          </div>
          <h3 className="text-3xl font-black mb-2">Scores</h3>
          <p className="text-slate-600 font-medium">Firebase Demo</p>
        </CartoonCard>
      </motion.div>
    </div>

    <div className="mt-12">
      <CartoonCard variant="yellow" className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="text-5xl">🏆</div>
          <div>
            <h4 className="text-2xl font-black">Next Reward</h4>
            <p className="text-slate-600">Earn 11 more stars to unlock the Super Cape!</p>
          </div>
        </div>
        <div className="w-64 h-4 bg-white/50 rounded-full cartoon-border overflow-hidden">
          <div className="h-full bg-brand-yellow w-[80%]" />
        </div>
      </CartoonCard>
    </div>
  </div>
);

const MathGame = ({ onBack }: { onBack: () => void }) => {
  const [question, setQuestion] = useState({ a: 3, b: 2, op: '+' });
  const [options, setOptions] = useState([4, 5, 6]);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  // Speak question on load and when it changes
  useEffect(() => {
    const text = `What is ${question.a} plus ${question.b}?`;
    speakService.speak(text);
  }, [question]);

  const handleAnswer = (val: number) => {
    if (val === question.a + question.b) {
      setFeedback('correct');
      soundService.play('correct');
      speakService.speak('Great job! That is correct.');
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      setTimeout(() => {
        setFeedback(null);
        generateQuestion();
      }, 2500);
    } else {
      setFeedback('wrong');
      soundService.play('wrong');
      speakService.speak('Not quite. Try again!');
      setTimeout(() => setFeedback(null), 1500);
    }
  };

  const generateQuestion = () => {
    const a = Math.floor(Math.random() * 5) + 1;
    const b = Math.floor(Math.random() * 4) + 1;
    const ans = a + b;
    setQuestion({ a, b, op: '+' });
    const opts = [ans, ans + 1, ans - 1].sort(() => Math.random() - 0.5);
    setOptions(opts);
  };

  const replayInstruction = () => {
    speakService.speak(`What is ${question.a} plus ${question.b}?`);
  };

  return (
    <div className="h-screen w-full p-8 bg-brand-blue/5 flex flex-col">
      <header className="flex justify-between items-center mb-8">
        <CartoonButton variant="white" className="p-3" onClick={() => { soundService.play('click'); onBack(); }}>
          <ChevronLeft size={24} />
        </CartoonButton>
        <div className="flex items-center gap-4">
          <div className="text-2xl font-black">Math Adventure</div>
          <div className="bg-white px-4 py-2 rounded-xl cartoon-border font-bold">Score: 12</div>
        </div>
        <AudioControls onReplay={replayInstruction} />
      </header>

      <div className="flex-1 flex flex-col items-center justify-center gap-12">
        <CartoonCard className="w-full max-w-2xl p-12 text-center relative">
          <h2 className="text-7xl font-black mb-12 font-display">
            {question.a} {question.op} {question.b} = ?
          </h2>
          
          <div className="flex justify-center gap-8 mb-4">
            <div className="flex flex-wrap gap-2 max-w-[200px] justify-center">
              {Array.from({ length: question.a }).map((_, i) => (
                <div key={`a-${i}`} className="text-4xl animate-float" style={{ animationDelay: `${i * 0.1}s` }}>🍎</div>
              ))}
            </div>
            <div className="text-4xl font-black self-center">+</div>
            <div className="flex flex-wrap gap-2 max-w-[200px] justify-center">
              {Array.from({ length: question.b }).map((_, i) => (
                <div key={`b-${i}`} className="text-4xl animate-float" style={{ animationDelay: `${i * 0.1}s` }}>🍎</div>
              ))}
            </div>
          </div>

          <AnimatePresence>
            {feedback && (
              <motion.div 
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                className={cn(
                  "absolute inset-0 flex items-center justify-center bg-white/90 rounded-2xl z-20",
                  feedback === 'correct' ? "text-brand-green" : "text-brand-pink"
                )}
              >
                {feedback === 'correct' ? (
                  <div className="flex flex-col items-center">
                    <CheckCircle2 size={120} />
                    <span className="text-4xl font-black mt-4">AMAZING!</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <XCircle size={120} />
                    <span className="text-4xl font-black mt-4">TRY AGAIN!</span>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </CartoonCard>

        <div className="flex gap-8">
          {options.map((opt) => (
            <CartoonButton 
              key={opt} 
              size="xl" 
              variant="yellow" 
              className="w-32 h-32 flex items-center justify-center text-5xl"
              onClick={() => handleAnswer(opt)}
            >
              {opt}
            </CartoonButton>
          ))}
        </div>
      </div>

      <footer className="flex justify-center gap-4 mt-8">
        <CartoonButton variant="white" className="p-4" onClick={generateQuestion}>
          <RotateCcw size={24} />
          <span className="ml-2">New Question</span>
        </CartoonButton>
      </footer>
    </div>
  );
};

const EnglishModule = ({ onBack, onStartTracing }: { onBack: () => void, onStartTracing: (letter: string) => void }) => {
  const alphabet = ['A', 'B', 'C', 'D', 'E', 'F'];
  const [currentIdx, setCurrentIdx] = useState(0);
  
  const items = {
    A: { word: 'Apple', icon: '🍎', sound: 'Crunch!', color: '#FFDAC1' },
    B: { word: 'Ball', icon: '⚽', sound: 'Boing!', color: '#A0D2EB' },
    C: { word: 'Cat', icon: '🐱', sound: 'Meow!', color: '#B5EAD7' },
    D: { word: 'Dog', icon: '🐶', sound: 'Woof!', color: '#FFF1B5' },
    E: { word: 'Elephant', icon: '🐘', sound: 'Trumpet!', color: '#E0BBE4' },
    F: { word: 'Fish', icon: '🐟', sound: 'Glub!', color: '#FFDAC1' },
  };

  const current = alphabet[currentIdx];
  const data = items[current as keyof typeof items];

  // Speak letter on change
  useEffect(() => {
    speakService.speak(`The letter ${current}`);
  }, [current]);

  const handleLetterClick = () => {
    const phrase = `${current} for ${data.word}`;
    console.log(`🖱️ Clicked letter: ${current}. Phrase: ${phrase}`);
    speakService.speak(phrase);
  };

  const handleImageClick = () => {
    console.log(`🖱️ Clicked image: ${data.icon}. Word: ${data.word}`);
    speakService.speak(data.word);
  };

  const replayInstruction = () => {
    speakService.speak(`This is the letter ${current}. ${current} is for ${data.word}.`);
  };

  return (
    <div className="h-screen w-full p-8 bg-brand-pink/5 flex flex-col">
      <header className="flex justify-between items-center mb-8">
        <CartoonButton variant="white" className="p-3" onClick={() => { soundService.play('click'); onBack(); }}>
          <ChevronLeft size={24} />
        </CartoonButton>
        <div className="text-2xl font-black">Alphabet Fun</div>
        <AudioControls onReplay={replayInstruction} />
      </header>

      <div className="flex-1 flex items-center justify-center gap-12">
        <CartoonButton 
          variant="white" 
          className="p-4" 
          onClick={() => {
            soundService.play('click');
            setCurrentIdx(prev => Math.max(0, prev - 1));
          }}
          disabled={currentIdx === 0}
        >
          <ChevronLeft size={48} />
        </CartoonButton>

        <CartoonCard className="w-full max-w-3xl h-[500px] flex flex-col items-center justify-center gap-8 relative overflow-hidden">
          <div className="absolute top-4 left-4 text-9xl opacity-10 font-black">{current}</div>
          
          <motion.div 
            key={current}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex flex-col items-center gap-6"
          >
            <button 
              onClick={handleLetterClick}
              className="text-[180px] leading-none font-black text-brand-pink-dark font-display hover:scale-105 transition-transform"
            >
              {current}
            </button>
            <button 
              onClick={handleImageClick}
              className="text-9xl animate-float hover:scale-110 transition-transform"
            >
              {data.icon}
            </button>
            <button 
              onClick={handleImageClick}
              className="text-5xl font-black hover:text-brand-pink-dark transition-colors"
            >
              {data.word}
            </button>
            
            <div className="flex gap-4 mt-4">
              <CartoonButton 
                variant="pink" 
                size="lg" 
                onClick={() => speakService.speak(data.word)}
              >
                <div className="flex items-center gap-3">
                  <Volume2 size={32} />
                  HEAR
                </div>
              </CartoonButton>
              
              <CartoonButton 
                variant="purple" 
                size="lg" 
                onClick={() => { soundService.play('transition'); onStartTracing(current); }}
              >
                <div className="flex items-center gap-3">
                  <Sparkles size={32} />
                  MAGIC WRITE
                </div>
              </CartoonButton>
            </div>
          </motion.div>
        </CartoonCard>

        <CartoonButton 
          variant="white" 
          className="p-4" 
          onClick={() => {
            soundService.play('click');
            setCurrentIdx(prev => Math.min(alphabet.length - 1, prev + 1));
          }}
          disabled={currentIdx === alphabet.length - 1}
        >
          <ChevronLeft size={48} className="rotate-180" />
        </CartoonButton>
      </div>

      <div className="flex justify-center gap-4 mt-8">
        {alphabet.map((letter, i) => (
          <button
            key={letter}
            onClick={() => setCurrentIdx(i)}
            className={cn(
              "w-12 h-12 rounded-full cartoon-border font-bold transition-all",
              currentIdx === i ? "bg-brand-pink text-white scale-110" : "bg-white text-slate-400"
            )}
          >
            {letter}
          </button>
        ))}
      </div>
    </div>
  );
};

const ProgressDashboard = ({ onBack }: { onBack: () => void }) => (
  <div className="h-screen w-full p-8 bg-brand-green/5 flex flex-col overflow-y-auto">
    <header className="flex justify-between items-center mb-12">
      <CartoonButton variant="white" className="p-3" onClick={onBack}>
        <ChevronLeft size={24} />
      </CartoonButton>
      <h2 className="text-4xl font-black font-display">My Progress</h2>
      <div className="w-12" />
    </header>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
      <CartoonCard className="h-96">
        <h3 className="text-2xl font-black mb-6 flex items-center gap-2">
          <BarChart3 className="text-brand-blue" />
          Daily Learning
        </h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={PROGRESS_DATA}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="day" axisLine={false} tickLine={false} />
              <YAxis axisLine={false} tickLine={false} />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: '4px solid #1e293b', fontWeight: 'bold' }}
              />
              <Bar dataKey="math" fill="#A0D2EB" radius={[8, 8, 0, 0]} />
              <Bar dataKey="english" fill="#FFDAC1" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CartoonCard>

      <CartoonCard className="h-96">
        <h3 className="text-2xl font-black mb-6 flex items-center gap-2">
          <Award className="text-brand-yellow" />
          Weekly Improvement
        </h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={WEEKLY_DATA}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="week" axisLine={false} tickLine={false} />
              <YAxis axisLine={false} tickLine={false} />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: '4px solid #1e293b', fontWeight: 'bold' }}
              />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke="#B5EAD7" 
                strokeWidth={6} 
                dot={{ r: 8, fill: '#B5EAD7', stroke: '#1e293b', strokeWidth: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CartoonCard>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <CartoonCard variant="blue" className="text-center">
        <div className="text-4xl font-black mb-2">92%</div>
        <div className="text-slate-600 font-bold uppercase text-sm tracking-widest">Accuracy</div>
      </CartoonCard>
      <CartoonCard variant="pink" className="text-center">
        <div className="text-4xl font-black mb-2">4.5h</div>
        <div className="text-slate-600 font-bold uppercase text-sm tracking-widest">Time Spent</div>
      </CartoonCard>
      <CartoonCard variant="yellow" className="text-center">
        <div className="text-4xl font-black mb-2">12</div>
        <div className="text-slate-600 font-bold uppercase text-sm tracking-widest">Badges Earned</div>
      </CartoonCard>
    </div>
  </div>
);

const TracingModule = ({ letter, onBack }: { letter: string, onBack: () => void }) => {
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    speakService.speak(`Magic Writing! Trace the letter ${letter}.`);
  }, [letter]);

  const handleDone = () => {
    setIsDone(true);
    soundService.play('correct');
    speakService.speak(`Great job! You wrote the letter ${letter}!`);
    confetti({
      particleCount: 150,
      spread: 100,
      origin: { y: 0.6 }
    });
  };

  const replayInstruction = () => {
    speakService.speak(`Trace the letter ${letter} with your finger.`);
  };

  return (
    <div className="h-screen w-full p-8 bg-brand-purple/5 flex flex-col">
      <header className="flex justify-between items-center mb-8">
        <CartoonButton variant="white" className="p-3" onClick={() => { soundService.play('click'); onBack(); }}>
          <ChevronLeft size={24} />
        </CartoonButton>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-brand-purple rounded-full flex items-center justify-center cartoon-border">
            <Sparkles size={24} className="text-white" />
          </div>
          <div className="text-2xl font-black">Magic Writing: {letter}</div>
        </div>
        <AudioControls onReplay={replayInstruction} />
      </header>

      <div className="flex-1 flex flex-col items-center justify-center gap-8">
        <div className="w-full max-w-4xl h-[600px] relative">
          <AirWritingCanvas 
            targetLetter={letter} 
            color="#E0BBE4" 
            className="h-full"
          />
          
          <AnimatePresence>
            {isDone && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 bg-white/90 rounded-3xl z-50 flex flex-col items-center justify-center p-12 text-center"
              >
                <div className="text-9xl mb-8 animate-bounce">🌟</div>
                <h2 className="text-6xl font-black mb-4 font-display">Magical!</h2>
                <p className="text-2xl text-slate-600 mb-12">You are a writing wizard!</p>
                <div className="flex gap-4">
                  <CartoonButton variant="white" size="lg" onClick={() => setIsDone(false)}>
                    <RotateCcw size={24} className="mr-2" />
                    Write Again
                  </CartoonButton>
                  <CartoonButton variant="purple" size="lg" onClick={onBack}>
                    <ArrowRight size={24} className="mr-2" />
                    Next Letter
                  </CartoonButton>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {!isDone && (
          <CartoonButton size="lg" variant="green" onClick={handleDone}>
            <div className="flex items-center gap-3">
              <CheckCircle2 size={32} />
              I'M DONE!
            </div>
          </CartoonButton>
        )}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [tracingLetter, setTracingLetter] = useState('A');

  const handleStart = () => setScreen('profiles');
  const handleProfileSelect = (p: Profile) => {
    setActiveProfile(p);
    setScreen('dashboard');
  };

  const startTracing = (letter: string) => {
    setTracingLetter(letter);
    setScreen('tracing');
  };

  return (
    <div className="min-h-screen w-full bg-[#FDFCF0] font-sans">
      <AnimatePresence mode="wait">
        {screen === 'welcome' && (
          <motion.div key="welcome" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <WelcomeScreen onStart={handleStart} />
          </motion.div>
        )}

        {screen === 'profiles' && (
          <motion.div key="profiles" initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -100 }}>
            <ProfileSelection onSelect={handleProfileSelect} />
          </motion.div>
        )}

        {screen === 'dashboard' && activeProfile && (
          <motion.div key="dashboard" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.1 }}>
            <Dashboard profile={activeProfile} onNavigate={setScreen} />
          </motion.div>
        )}

        {screen === 'math' && (
          <motion.div key="math" initial={{ opacity: 0, y: 100 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -100 }}>
            <MathGame onBack={() => setScreen('dashboard')} />
          </motion.div>
        )}

        {screen === 'english' && (
          <motion.div key="english" initial={{ opacity: 0, y: 100 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -100 }}>
            <EnglishModule onBack={() => setScreen('dashboard')} onStartTracing={startTracing} />
          </motion.div>
        )}

        {screen === 'tracing' && (
          <motion.div key="tracing" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.2 }}>
            <TracingModule letter={tracingLetter} onBack={() => setScreen('english')} />
          </motion.div>
        )}

        {screen === 'scores' && (
          <motion.div key="scores" initial={{ opacity: 0, y: 100 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -100 }}>
            <div className="h-screen w-full p-8 bg-white overflow-y-auto">
              <CartoonButton variant="white" className="p-3 mb-8" onClick={() => setScreen('dashboard')}>
                <ChevronLeft size={24} />
              </CartoonButton>
              <ScoreTracker />
            </div>
          </motion.div>
        )}

        {screen === 'progress' && (
          <motion.div key="progress" initial={{ opacity: 0, x: -100 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 100 }}>
            <ProgressDashboard onBack={() => setScreen('dashboard')} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation Bar (Only visible on dashboard and game screens) */}
      {['dashboard', 'math', 'english', 'progress', 'tracing', 'scores'].includes(screen) && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
          <div className="bg-white cartoon-border cartoon-shadow rounded-2xl p-2 flex gap-2">
            <button 
              onClick={() => setScreen('dashboard')}
              className={cn(
                "p-4 rounded-xl transition-all",
                screen === 'dashboard' ? "bg-brand-blue text-white" : "hover:bg-slate-100 text-slate-400"
              )}
            >
              <Home size={28} />
            </button>
            <button 
              onClick={() => setScreen('progress')}
              className={cn(
                "p-4 rounded-xl transition-all",
                screen === 'progress' ? "bg-brand-green text-white" : "hover:bg-slate-100 text-slate-400"
              )}
            >
              <BarChart3 size={28} />
            </button>
            <button className="p-4 rounded-xl hover:bg-slate-100 text-slate-400">
              <User size={28} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
