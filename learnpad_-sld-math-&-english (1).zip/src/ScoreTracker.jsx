import React, { useState, useEffect } from 'react';
import { db } from './firebase';
import { 
  collection, 
  addDoc, 
  onSnapshot, 
  serverTimestamp, 
  query, 
  orderBy, 
  limit, 
  deleteDoc, 
  doc 
} from "firebase/firestore";
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, Plus, Trophy, User, Calendar, AlertCircle } from 'lucide-react';

function ScoreTracker() {
  const [scores, setScores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // --- 1. FETCH DATA (REAL-TIME, SORTED, LIMITED) ---
  useEffect(() => {
    console.log("👂 Starting real-time listener...");
    
    // Query: Sort by score (highest first) and limit to latest 10
    const q = query(
      collection(db, "scores"), 
      orderBy("score", "desc"), 
      limit(10)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const scoresArray = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setScores(scoresArray);
      setLoading(false);
    }, (error) => {
      console.error("❌ Firestore Error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // --- 2. SAVE DATA ---
  const saveScore = async () => {
    setIsSaving(true);
    try {
      const names = ["Alex", "Sam", "Jordan", "Taylor", "Charlie", "Riley", "Casey"];
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomScore = Math.floor(Math.random() * 50) + 50; // 50-100

      await addDoc(collection(db, "scores"), {
        name: randomName,
        score: randomScore,
        timestamp: serverTimestamp()
      });
      console.log("✅ Score saved!");
    } catch (error) {
      alert("Oops! Couldn't save the score: " + error.message);
    } finally {
      setIsSaving(false);
    }
  };

  // --- 3. DELETE DATA ---
  const deleteScore = async (id) => {
    if (window.confirm("Are you sure you want to delete this score? 🗑️")) {
      try {
        await deleteDoc(doc(db, "scores", id));
        console.log("🗑️ Score deleted!");
      } catch (error) {
        alert("Couldn't delete: " + error.message);
      }
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-sky-50 min-h-screen font-sans">
      {/* Header Section */}
      <header className="text-center mb-10">
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="inline-block p-4 bg-white rounded-3xl shadow-xl mb-4 border-4 border-yellow-400"
        >
          <Trophy className="w-12 h-12 text-yellow-500 mx-auto" />
        </motion.div>
        <h1 className="text-4xl font-black text-slate-800 mb-2 tracking-tight">
          Learning Champions! 🌟
        </h1>
        <p className="text-slate-500 font-medium">Top 10 Scores this week</p>
      </header>

      {/* Action Button */}
      <div className="flex justify-center mb-12">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={saveScore}
          disabled={isSaving}
          className="flex items-center gap-3 px-8 py-4 bg-green-500 hover:bg-green-600 text-white text-xl font-bold rounded-2xl shadow-lg shadow-green-200 transition-colors disabled:opacity-50"
        >
          <Plus className="w-6 h-6" />
          {isSaving ? "Saving..." : "Add New Score"}
        </motion.button>
      </div>

      {/* Scores List */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center p-10">
            <div className="animate-spin w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-slate-400 font-bold">Connecting to the cloud...</p>
          </div>
        ) : scores.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white p-12 rounded-3xl border-4 border-dashed border-slate-200 text-center"
          >
            <AlertCircle className="w-16 h-16 text-slate-200 mx-auto mb-4" />
            <p className="text-slate-400 text-xl font-bold">No scores yet. Be the first!</p>
          </motion.div>
        ) : (
          <AnimatePresence mode="popLayout">
            {scores.map((s, index) => (
              <motion.div
                key={s.id}
                layout
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 20, opacity: 0 }}
                transition={{ delay: index * 0.05 }}
                className="group bg-white p-5 rounded-2xl shadow-sm border-2 border-slate-100 flex items-center justify-between hover:shadow-md hover:border-blue-200 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl ${
                    index === 0 ? 'bg-yellow-100 text-yellow-600' : 
                    index === 1 ? 'bg-slate-100 text-slate-600' : 
                    index === 2 ? 'bg-orange-100 text-orange-600' : 'bg-blue-50 text-blue-400'
                  }`}>
                    {index + 1}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-400" />
                      <span className="font-bold text-slate-700 text-lg">{s.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-400 text-sm">
                      <Calendar className="w-3 h-3" />
                      <span>{s.timestamp?.toDate().toLocaleDateString() || "Just now"}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-2xl font-black text-blue-600">{s.score}</div>
                    <div className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Points</div>
                  </div>
                  
                  <button 
                    onClick={() => deleteScore(s.id)}
                    className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                    title="Delete Score"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      <footer className="mt-12 text-center text-slate-400 text-sm font-medium">
        Showing top 10 champions • Updated in real-time
      </footer>
    </div>
  );
}

export default ScoreTracker;
